# Recipe Box - a Free Code Camp Project (FCC)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaro-carneiro/pen/poaWjKZ](https://codepen.io/alvaro-carneiro/pen/poaWjKZ).

Recipe box built with React. This was built as a Free Code Camp (FCC) project.