# Calculadora em PHP - Alvaro Antonio Carneiro

Github: https://github.com/alvaro-carneiro/Carneiro
Email: alvaro_carneiro@hotmail.com

Este é um exemplo simples de uma calculadora implementada em PHP que permite que o usuário realize operações de adição, subtração, multiplicação e divisão entre dois números.

## Como usar

1. Clone ou baixe este repositório para o seu ambiente de desenvolvimento.

2. Abra o arquivo `calculadora.php` em um navegador da web ou em um servidor PHP local.

3. Insira dois números nos campos de entrada "Número 1" e "Número 2".

4. Escolha a operação desejada no menu suspenso "Operação".

5. Clique no botão "Calcular" para ver o resultado da operação escolhida.

## Operações suportadas

- **Adição:** Soma os dois números inseridos.
- **Subtração:** Subtrai o segundo número do primeiro.
- **Multiplicação:** Multiplica os dois números.
- **Divisão:** Divide o primeiro número pelo segundo. Nota: Divisão por zero não é permitida.

## Observações

- Certifique-se de que o seu ambiente de desenvolvimento tenha suporte a PHP para executar o código.
- Este exemplo é destinado a fins educacionais e de demonstração. Em sistemas reais, é importante implementar validações robustas e tratamento de erros.
- Este código não inclui medidas de segurança avançadas, portanto, não o utilize em um ambiente de produção sem as devidas precauções.

## Licença

  fornecido sob a licença [MIT](LICENSE).